package com.vismod.gui;

import com.vismod.render.GlassRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * A branded splash shown for a short, fixed duration right after launch,
 * before VisModClient swaps in CustomTitleScreen. Purely decorative - no
 * actual asset loading happens here, Minecraft's own resource loading is
 * already done by the time any Screen can render, so this is just a
 * glass progress-bar-style flourish.
 */
public class CustomLoadingScreen extends Screen {

    private static final long DURATION_MS = 1400;
    private final long startedAt = System.currentTimeMillis();
    private final Runnable onFinished;
    private boolean finished = false;

    public CustomLoadingScreen(Runnable onFinished) {
        super(Text.literal("Loading"));
        this.onFinished = onFinished;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fillGradient(0, 0, width, height, 0xFF101014, 0xFF030305);

        long elapsed = System.currentTimeMillis() - startedAt;
        float progress = Math.min(1f, elapsed / (float) DURATION_MS);

        int barWidth = 260;
        int barHeight = 10;
        int x = width / 2 - barWidth / 2;
        int y = height / 2 + 20;

        GlassRenderer.panel(context, x, y, barWidth, barHeight, 0x30000000, 0x30FFFFFF);
        context.fill(x + 2, y + 2, x + 2 + (int) ((barWidth - 4) * progress), y + barHeight - 2, 0xFFB479F0);

        context.drawCenteredTextWithShadow(textRenderer, Text.literal("VisMod"), width / 2, height / 2 - 20, 0xFFFFFFFF);

        if (progress >= 1f && !finished) {
            finished = true;
            if (onFinished != null) onFinished.run();
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
}
