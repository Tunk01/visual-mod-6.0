package com.vismod.module.modules;

import com.vismod.config.ModuleVisualConfig;
import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.render.CustomEffectManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.random.Random;

/**
 * Shared implementation for the remaining safe cosmetic modules. Every
 * visual is custom geometry and is driven only by client-visible state.
 */
public class CosmeticModule extends Module {
    private final Random random = Random.create();

    public CosmeticModule(String id, String name, ModuleCategory category, String description) {
        super(id, name, category, description, false);
    }

    @Override public void onClientTick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null || client.player == null || client.isPaused()) return;
        ModuleVisualConfig.Settings style = ModuleVisualConfig.get(id());
        if (style.nightOnly && !world.isNight()) return;
        if (world.getTime() % Math.max(1, Math.round(8f / style.animationSpeed)) != 0) return;

        if (id().equals("light_pillars")) {
            renderVisibleItemPillars(client, world, style);
            return;
        }

        if (isEntityEffect()) {
            int emitted = 0;
            for (Entity entity : world.getEntities()) {
                if (entity == client.player || !client.player.canSee(entity)) continue;
                if (client.player.squaredDistanceTo(entity) > style.spawnRadius * style.spawnRadius) continue;
                emitForEntity(entity, style);
                if (++emitted >= Math.max(1, style.effectCount / 20)) break;
            }
            return;
        }

        if (isMotionEffect()) {
            double vx = client.player.getVelocity().x;
            double vz = client.player.getVelocity().z;
            double speed = Math.sqrt(vx * vx + vz * vz);
            if (speed > 0.04) {
                CustomEffectManager.emit(id(), CustomEffectManager.Type.TRAIL,
                        client.player.getX(), client.player.getY() + 0.15, client.player.getZ(),
                        -client.player.getVelocity().x * 0.2, 0.01, -client.player.getVelocity().z * 0.2,
                        28, 0.18f);
            }
            return;
        }

        int count = Math.max(1, Math.min(5, style.effectCount / 35));
        for (int i = 0; i < count; i++) {
            double radius = style.spawnRadius;
            double x = client.player.getX() + (random.nextDouble() - 0.5) * radius;
            double y = client.player.getY() + 0.5 + random.nextDouble() * 4.0;
            double z = client.player.getZ() + (random.nextDouble() - 0.5) * radius;
            CustomEffectManager.Type type = typeFor(id());
            CustomEffectManager.emit(id(), type, x, y, z,
                    0, type == CustomEffectManager.Type.RING ? 0.018 : 0.008, 0,
                    36, 0.14f);
        }
    }

    private void renderVisibleItemPillars(MinecraftClient client, ClientWorld world, ModuleVisualConfig.Settings style) {
        int emitted = 0;
        for (Entity entity : world.getEntities()) {
            if (!(entity instanceof ItemEntity item)) continue;
            if (!client.player.canSee(item)) continue; // prevents pillars through walls
            if (client.player.squaredDistanceTo(item) > style.spawnRadius * style.spawnRadius) continue;
            CustomEffectManager.emit(id(), CustomEffectManager.Type.BEAM,
                    item.getX(), item.getY(), item.getZ(), 0, 0, 0, 14, 0.32f);
            if (++emitted >= Math.max(1, style.effectCount / 20)) break;
        }
    }

    private void emitForEntity(Entity entity, ModuleVisualConfig.Settings style) {
        CustomEffectManager.Type type = typeFor(id());
        CustomEffectManager.emit(id(), type, entity.getX(), entity.getY() + entity.getHeight() * 0.5,
                entity.getZ(), 0, 0.012, 0, 26, 0.18f);
    }

    private boolean isEntityEffect() {
        return id().contains("wings") || id().contains("hat") || id().contains("relic")
                || id().contains("mobs") || id().contains("dropped") || id().contains("projectile")
                || id().contains("crystal") || id().contains("armor") || id().contains("totem");
    }

    private boolean isMotionEffect() {
        return id().contains("animation") || id().contains("afterimage") || id().contains("swing")
                || id().contains("camera") || id().contains("viewmodel") || id().contains("fov");
    }

    private CustomEffectManager.Type typeFor(String id) {
        if (id.contains("ring") || id.contains("fairy") || id.contains("experience")) return CustomEffectManager.Type.RING;
        if (id.contains("explosion") || id.contains("damage") || id.contains("attack")) return CustomEffectManager.Type.SPARK;
        if (id.contains("fire") || id.contains("ember") || id.contains("rift")) return CustomEffectManager.Type.FLAME;
        if (id.contains("smoke") || id.contains("atmosphere")) return CustomEffectManager.Type.SMOKE;
        if (id.contains("soul") || id.contains("crystal") || id.contains("angel") || id.contains("totem")) return CustomEffectManager.Type.AURA;
        return CustomEffectManager.Type.DUST;
    }
}