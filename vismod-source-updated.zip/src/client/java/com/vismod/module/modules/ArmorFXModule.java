package com.vismod.module.modules;

import com.vismod.config.ModuleVisualConfig;
import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.render.CustomEffectManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.random.Random;

/** Custom geometric aura for fully equipped players; no vanilla particles are created. */
public class ArmorFXModule extends Module {
    private final Random random = Random.create();
    public ArmorFXModule() { super("armor_fx", "ArmorFX", ModuleCategory.ENTITIES,
            "Custom floating aura geometry around fully equipped players.", true); }

    @Override public void onClientTick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null) return;
        ModuleVisualConfig.Settings style = ModuleVisualConfig.get("armor_fx");
        if (style.nightOnly && !world.isNight()) return;
        for (PlayerEntity player : world.getPlayers()) {
            if (!hasFullArmor(player)) continue;
            if (random.nextFloat() > Math.min(1f, 0.3f * style.effectCount / 80f)) continue;
            double radius = player.getWidth() * style.size;
            CustomEffectManager.emit("armor_fx", CustomEffectManager.Type.AURA,
                    player.getX() + (random.nextDouble() - 0.5) * radius,
                    player.getY() + random.nextDouble() * player.getHeight(),
                    player.getZ() + (random.nextDouble() - 0.5) * radius,
                    0, 0.01, 0, 26, 0.22f);
        }
    }

    private boolean hasFullArmor(PlayerEntity player) {
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            if (player.getEquippedStack(slot).isEmpty()) return false;
        }
        return true;
    }
}