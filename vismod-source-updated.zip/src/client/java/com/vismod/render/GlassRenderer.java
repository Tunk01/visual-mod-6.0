package com.vismod.render;

import com.vismod.config.VisualConfig;
import net.minecraft.client.gui.DrawContext;

/** Layered rounded glass surfaces used throughout VisMod screens and widgets. */
public final class GlassRenderer {
    private GlassRenderer() {}

    public static void blurBackdrop(DrawContext context) { context.applyBlur(); }

    public static void panel(DrawContext context, int x, int y, int width, int height, int fillArgb, int borderArgb) {
        if (width <= 2 || height <= 2) return;
        int radius = Math.min(18, Math.min(width, height) / 2);
        int alpha = (int) (((fillArgb >>> 24) & 0xFF) * VisualConfig.get().menuOpacity);
        int fill = (fillArgb & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
        int border = (borderArgb & 0x00FFFFFF) | (((borderArgb >>> 24) & 0xFF) << 24);
        int x2 = x + width;
        int y2 = y + height;

        // Two overlapping slabs leave rounded, transparent corners.
        context.fill(x + radius, y, x2 - radius, y2, fill);
        context.fill(x, y + radius, x2, y2 - radius, fill);
        context.fillGradient(x + radius, y + 1, x2 - radius, y + Math.max(2, height / 3),
                withAlpha(0xFFFFFFFF, 0x28), 0x00000000);

        // Soft luminous border, split around the curved corners.
        context.fill(x + radius, y, x2 - radius, y + 1, border);
        context.fill(x + radius, y2 - 1, x2 - radius, y2, withAlpha(border, 0x24));
        context.fill(x, y + radius, x + 1, y2 - radius, withAlpha(border, 0xC0));
        context.fill(x2 - 1, y + radius, x2, y2 - radius, withAlpha(border, 0xC0));
        context.fill(x + radius, y + 1, x2 - radius, y + 2, withAlpha(0xFFFFFFFF, 0x22));
        context.fill(x + radius, y2 - 2, x2 - radius, y2 - 1, withAlpha(0x00000000, 0x20));
    }

    public static void button(DrawContext context, int x, int y, int width, int height, boolean hovered) {
        panel(context, x, y, width, height,
                hovered ? 0x702C4054 : 0x4A172332,
                hovered ? 0xB0C4F5FF : 0x657EA0B8);
    }

    private static int withAlpha(int color, int alpha) { return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24); }
}