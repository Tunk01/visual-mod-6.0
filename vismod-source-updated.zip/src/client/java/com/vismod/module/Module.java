package com.vismod.module;

import net.minecraft.client.MinecraftClient;
import com.vismod.gui.ModuleSettingsScreen;

/**
 * A single toggleable visual feature (one row in the config screen, e.g.
 * "ArmorFX" or "Player Trails"). Modules are cheap, stateless-by-default
 * objects registered once in {@link ModuleManager}; their only mutable
 * state is the enabled flag, which is persisted to disk.
 *
 * Implementations should keep onEnable/onDisable fast (just flipping
 * flags / clearing caches) and do the actual work in onClientTick /
 * render hooks, which the manager only calls for modules that are
 * currently enabled.
 */
public abstract class Module {

    private final String id;           // stable key, used in config.json - never change once shipped
    private final String displayName;  // shown in the UI list
    private final ModuleCategory category;
    private final String description;  // shown as a tooltip
    private boolean enabled;
    private boolean starred;

    protected Module(String id, String displayName, ModuleCategory category, String description, boolean enabledByDefault) {
        this.id = id;
        this.displayName = displayName;
        this.category = category;
        this.description = description;
        this.enabled = enabledByDefault;
    }

    public final String id() {
        return id;
    }

    public final String displayName() {
        return displayName;
    }

    public final ModuleCategory category() {
        return category;
    }

    public final String description() {
        return description;
    }

    public final boolean isEnabled() {
        return enabled;
    }

    public final boolean isStarred() {
        return starred;
    }

    public final void setStarred(boolean starred) {
        this.starred = starred;
    }

    /** Called by the manager when a toggle flips. Never call directly from UI. */
    public final void setEnabled(boolean enabled) {
        if (this.enabled == enabled) return;
        this.enabled = enabled;
        MinecraftClient client = MinecraftClient.getInstance();
        if (enabled) {
            onEnable(client);
        } else {
            onDisable(client);
        }
    }

    /** Fired once when the module is turned on (including at startup if enabled in config). */
    protected void onEnable(MinecraftClient client) {}

    /** Fired once when the module is turned off. Clean up any caches/particles here. */
    protected void onDisable(MinecraftClient client) {}

    /** Called every client tick while enabled. Override for per-tick logic (spawn particles, etc). */
    public void onClientTick(MinecraftClient client) {}

    /**
     * Does this module expose extra sliders/color pickers beyond a plain
     * on/off switch? If so, override {@link #openSettings} to push a
     * sub-screen; the UI shows a small gear icon next to the row.
     */
    public boolean hasExtraSettings() {
        return true;
    }

    public void openSettings(MinecraftClient client) {
        client.setScreen(new ModuleSettingsScreen(this, client.currentScreen));
    }
}
