package com.vismod.module.modules;

import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.config.VisualConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * IMPLEMENTED - "HUD overlay" template. Any purely-2D module (Now Playing,
 * Discord Rich Presence status pill, Performance, custom HUD elements)
 * hooks HudRenderCallback once in the constructor and draws only while
 * isEnabled() is true.
 */
public class PerformanceModule extends Module {

    public PerformanceModule() {
        super("performance", "Performance", ModuleCategory.HUD,
                "Small FPS counter in the corner of the screen.", true);
        HudRenderCallback.EVENT.register(this::onHudRender);
    }

    private void onHudRender(DrawContext context, net.minecraft.client.render.RenderTickCounter tickCounter) {
        if (!isEnabled()) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options.hudHidden) return;

        String text = client.getCurrentFps() + " fps";
        int x = 6;
        int y = 6;
        context.drawTextWithShadow(client.textRenderer, text, x, y, (0xA0 << 24) | (VisualConfig.get().primaryColor() & 0x00FFFFFF));
    }
}
