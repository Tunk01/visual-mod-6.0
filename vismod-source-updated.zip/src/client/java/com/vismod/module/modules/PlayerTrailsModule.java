package com.vismod.module.modules;

import com.vismod.config.ModuleVisualConfig;
import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.render.CustomEffectManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;

/** Custom ribbon-like trail geometry behind visible moving players. */
public class PlayerTrailsModule extends Module {
    private static final double SPEED_THRESHOLD = 0.18;
    public PlayerTrailsModule() { super("player_trails", "Player Trails", ModuleCategory.MOTION,
            "Custom glowing diamonds that trail visible fast-moving players.", true); }

    @Override public void onClientTick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null) return;
        ModuleVisualConfig.Settings style = ModuleVisualConfig.get("player_trails");
        if (style.nightOnly && !world.isNight()) return;
        for (PlayerEntity player : world.getPlayers()) {
            double dx = player.getVelocity().x, dz = player.getVelocity().z;
            if (Math.sqrt(dx * dx + dz * dz) < SPEED_THRESHOLD || player.isSneaking()) continue;
            int count = Math.max(1, Math.min(6, Math.round(style.effectCount / 40f)));
            for (int i = 0; i < count; i++) {
                CustomEffectManager.emit("player_trails", CustomEffectManager.Type.TRAIL,
                        player.getX(), player.getY() + 0.1, player.getZ(), -dx * 0.25, 0.012, -dz * 0.25, 24, 0.18f);
            }
        }
    }
}