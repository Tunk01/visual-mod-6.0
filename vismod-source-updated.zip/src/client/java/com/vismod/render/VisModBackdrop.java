package com.vismod.render;

import com.vismod.config.VisualConfig;
import net.minecraft.client.gui.DrawContext;

/** Navy glass-dashboard backdrop matching the VisMod UI mockup. */
public final class VisModBackdrop {
    private VisModBackdrop() {}

    public static void draw(DrawContext context, int width, int height, long nowMs) {
        int primary = VisualConfig.get().animatedPrimaryColor();
        context.fillGradient(0, 0, width, height, 0xFF233F78, 0xFF071426);
        context.fillGradient(0, 0, width, height / 2, (0x22 << 24) | (primary & 0x00FFFFFF), 0x001D315E);

        // Subtle skyline silhouette from the reference image.
        int skylineBase = height - Math.max(70, height / 5);
        for (int i = 0; i < 18; i++) {
            int buildingWidth = 26 + (i * 17) % 54;
            int buildingHeight = 45 + (i * 43) % Math.max(80, height / 3);
            int x = (i * 101) % Math.max(1, width);
            context.fill(x, skylineBase - buildingHeight, x + buildingWidth, skylineBase, 0x60101F31);
            if (i % 3 == 0) context.fill(x + 7, skylineBase - buildingHeight + 12, x + 9, skylineBase - buildingHeight + 14, 0x6570B7D0);
        }

        // Slow glass-dust motion keeps the screen alive without looking busy.
        for (int i = 0; i < 24; i++) {
            double phase = i * 2.417;
            int x = (int) ((i * 83 + nowMs / (24 + i % 5) + Math.sin(phase) * 40) % Math.max(1, width));
            int y = (int) ((i * 47 + nowMs / (34 + i % 7) + Math.cos(phase) * 24) % Math.max(1, height));
            context.fill(x, y, x + 2, y + 2, (0x28 << 24) | 0xD4F4FF);
        }
    }
}