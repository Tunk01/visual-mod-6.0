# VisMod — Fabric 1.21.11 client-side visuals suite (scaffold)

This is a **working starting point**, not a finished 72-module mod. Building
every module's actual render/particle/shader code with real effects is a
multi-week project on its own — what's here is the full plumbing (config
persistence, the module framework, the config GUI, the custom title/loading
screens) plus a growing set of implemented ambient effects and a fully animated glass UI.

## What's actually implemented

| Module | File | Pattern it demonstrates |
|---|---|---|
| ArmorFX | `ArmorFXModule.java` | tick-based ambient particle emitter |
| Fire+ | `FirePlusModule.java` | condition-based particle enhancement |
| Player Trails | `PlayerTrailsModule.java` | velocity-threshold particle trail |
| Jump Circles | `JumpCirclesModule.java` | edge-triggered (state-change) effect |
| Hit Effects | `HitEffectsModule.java` | health-diffing, no mixin needed |
| Performance | `PerformanceModule.java` | HudRenderCallback 2D overlay |
| Now Playing | `NowPlayingModule.java` | HUD overlay reading client state |
| Custom Crosshair | `CustomCrosshairModule.java` + `CrosshairMixin.java` | mixin-cancel + HUD redraw, extra-settings hook |
| Nametags | `FlagModule` + `NametagMixin.java` | pure mixin toggle, no Java logic needed |
| Weather | `FlagModule` + `WeatherMixin.java` | pure mixin toggle |
| Skyboxes | `AuroraSkyModule.java` | animated aurora curtains, `WorldRenderEvents.SKY` + raw geometry |
| Shooting Stars | `ShootingStarsModule.java` | spawning/lifetime system + tapered-tail sky geometry |

**Skyboxes** now draws 3 drifting aurora ribbon bands overhead (green →
cyan/violet gradient, layered sine-wave undulation, additive glow), active
whenever it's dark enough in the Overworld — same fade-in vanilla uses for
stars. **Shooting Stars** spawns a streak every ~15s on average once it's
properly dark, each sweeping across part of the dome over ~1 second with a
tapering, fading tail, up to 2 at once. Both are pure sky-dome geometry
(like vanilla's stars/sun/moon) so they don't cost particle budget and are
visible from anywhere, not just near the player.

Remaining cosmetic concepts are registered in
`ModuleRegistry.java` as a `StubModule` — it shows up in the config screen,
toggles, persists to `config/vismod/modules.json`, and does **nothing**
until you give it a real implementation following one of the patterns
above.

## What's implemented in the UI

- **Config screen** (`VisualsConfigScreen.java`) — search box, All /
  Entities / Motion / Starred filter chips, two-column paginated module
  list with star + toggle pill per row, matching your screenshots layout.
  Open it in-game with **Right Shift** (rebindable in Controls).
- **Custom title screen** (`CustomTitleScreen.java`) — big clock, date,
  "Good morning/afternoon/evening, <username>" greeting, glass
  Singleplayer/Multiplayer buttons, and a secondary row (Theme / Studio /
  Mods / Realms / Options / Quit). "Theme" opens a native file picker to
  import your own background image, which is remembered across restarts.
- **Custom loading screen** (`CustomLoadingScreen.java`) — a short branded
  splash with a glass progress bar shown once per launch, before the
  title screen.
- **Glassmorphism** (`GlassRenderer.java`, `GlassButton.java`) — translucent
  panels with a soft top highlight and thin border, plus an attempt to
  reuse Minecraft's built-in pause-menu blur shader for the backdrop.

## Things you (or a follow-up session) still need to do

1. **Pin real version numbers.** `1.21.11` may not correspond to an actual
   released Minecraft version by the time you build this — check
   fabricmc.net/develop for the real Minecraft/Yarn/Loader/Fabric API
   versions and update `gradle.properties`.
2. **Verify mapping-sensitive method names.** A few calls are marked with
   `NOTE:` comments because their exact signature shifts between Minecraft
   snapshots and I can't compile against the real game here:
   - `InGameHud#renderCrosshair` (CrosshairMixin)
   - `WorldRenderer#renderWeather` (WeatherMixin)
   - `NativeImageBackedTexture`'s constructor (BackgroundImageManager)
   - `DrawContext#drawTexture`'s exact overload (CustomTitleScreen)
   - `MatrixStack` push/pop/translate/scale naming (CustomTitleScreen)
   - Tessellator/BufferBuilder/RenderSystem immediate-mode draw calls
     (AuroraSkyModule, ShootingStarsModule) — Mojang has been reworking
     this layer in recent snapshots; the animation/math is stable, only
     the actual GPU submission calls might need updating
   - `ClientTickEvents.END_WORLD_TICK`'s exact signature (ShootingStarsModule)
   Open each in your IDE after importing the Gradle project — the IDE's
   autocomplete will show you the real signature instantly.
3. **`ModuleRow`'s row-management is intentionally simple** — it rebuilds
   all rows on every filter/search/page change rather than diffing. Fine
   for ~20 rows per page, but if you add animations later you may want to
   reuse widgets instead of recreating them.
4. **Implement the remaining 61 modules.** Pick whichever you want first;
   the patterns above cover "ambient particle," "condition-triggered
   particle," "HUD overlay," and "mixin toggle" — most of the list is one
   of those four shapes. A few (3D Swords, Capes & Elytra, Viewmodel,
   Totem Skins) need actual model/texture replacement, which is a bigger
   lift (custom `EntityModel`/`EquipmentModel` work) — worth tackling as
   their own session.
5. **Build a real settings sub-screen** for modules with
   `hasExtraSettings() == true` (currently just `CustomCrosshairModule`,
   with a `TODO` where the color-picker screen would go).

## Remaining cosmetic modules

The former placeholder registrations now use `CosmeticModule`, which emits custom geometry through `CustomEffectManager` and reads the same per-module settings. External asset/service features are omitted. Light Pillars are implemented with a client line-of-sight check and only appear for visible dropped items, never through walls.
## Custom effect renderer

Implemented effect modules use `CustomEffectManager`, a client-only geometry layer. Trails, flame, smoke, armor auras, jump rings, impact sparks, and ambient dust/fireflies are custom animated quads and diamonds rather than Minecraft `ParticleTypes`. Every effect reads its own saved module settings for count, radius, size, animation speed, opacity, night-only behavior, and colors.
## Per-module settings

Every module now opens a dedicated glass settings panel from its gear icon or row. Each module has independent saved controls for effect count, spawn radius, size, animation speed, opacity, night-only behavior, primary color, highlight color, enable state, and starred state. Settings are stored in `config/vismod/module-visuals.json` and remain client-only.
## Style Studio

The Style tab in the visual configuration screen opens a live client-only editor. It persists `config/vismod/visuals.json` and controls:

- Cyber, Aurora, Sunset, and Monochrome palettes
- Effect intensity and particle density
- Animation speed and menu opacity
- Glow and animated rainbow accent mode
- Custom crosshair size and color

These settings affect the implemented particle, sky, HUD, crosshair, button, and menu renderers. They do not send packets, alter player movement, or reveal server-side information.
## Building

```
./gradlew build
```

The output jar lands in `build/libs/`. Drop it in your `mods/` folder
alongside Fabric API for 1.21.11.

## Project layout

```
src/client/java/com/vismod/
  VisModClient.java              - entrypoint: registers modules, wires tick + screen-swap
  module/                        - the module framework (Module, ModuleManager, categories)
  module/modules/                - individual module implementations
  config/                        - JSON persistence + background-image import
  gui/                           - config screen, title screen, loading screen
  gui/widget/                    - GlassButton, ModuleRow
  render/                        - GlassRenderer (the glassmorphism look)
  mixin/                         - the 3 mixins (crosshair, nametags, weather)
```
