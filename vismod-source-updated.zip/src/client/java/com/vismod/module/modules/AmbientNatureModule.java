package com.vismod.module.modules;

import com.vismod.config.ModuleVisualConfig;
import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.render.CustomEffectManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.random.Random;

/** Custom floating dust and firefly geometry around the local camera. */
public class AmbientNatureModule extends Module {
    private final Random random = Random.create();
    public AmbientNatureModule() { super("ambient_particles", "Ambient Nature", ModuleCategory.WORLD,
            "Custom dust, firefly, and mist geometry around the local camera.", true); }

    @Override public void onClientTick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null || client.player == null || client.isPaused()) return;
        ModuleVisualConfig.Settings style = ModuleVisualConfig.get("ambient_particles");
        if (style.nightOnly && !world.isNight()) return;
        if (random.nextFloat() > Math.min(1f, 0.24f * style.effectCount / 80f)) return;
        double radius = style.spawnRadius;
        double x = client.player.getX() + (random.nextDouble() - 0.5) * radius;
        double y = client.player.getY() + 0.5 + random.nextDouble() * 4.0;
        double z = client.player.getZ() + (random.nextDouble() - 0.5) * radius;
        CustomEffectManager.emit("ambient_particles", CustomEffectManager.Type.DUST, x, y, z,
                0, 0.008, 0, 42, 0.12f);
    }
}