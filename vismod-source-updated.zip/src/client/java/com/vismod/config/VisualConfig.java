package com.vismod.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Persistent, client-only visual style shared by every implemented effect and screen. */
public final class VisualConfig {
    public enum Palette { CYBER, AURORA, SUNSET, MONO }

    public float intensity = 1.0f;
    public float particleDensity = 1.0f;
    public float animationSpeed = 1.0f;
    public float menuOpacity = 0.72f;
    public boolean glow = true;
    public boolean rainbow = false;
    public Palette palette = Palette.CYBER;
    public int crosshairColor = 0xFF8FE8FF;
    public int crosshairSize = 8;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("vismod").resolve("visuals.json");
    private static VisualConfig current;

    private VisualConfig() {}

    public static VisualConfig get() {
        if (current == null) load();
        return current;
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                try (Reader reader = Files.newBufferedReader(FILE, StandardCharsets.UTF_8)) {
                    current = GSON.fromJson(reader, VisualConfig.class);
                }
            }
        } catch (IOException | RuntimeException ignored) {}
        if (current == null) current = new VisualConfig();
        current.clamp();
        save();
    }

    public static void save() {
        if (current == null) return;
        current.clamp();
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE, StandardCharsets.UTF_8)) {
                GSON.toJson(current, VisualConfig.class, writer);
            }
        } catch (IOException ignored) {}
    }

    public void cyclePalette() {
        Palette[] values = Palette.values();
        palette = values[(palette.ordinal() + 1) % values.length];
        save();
    }

    public int primaryColor() {
        return switch (palette) {
            case AURORA -> 0xFF65F6C5;
            case SUNSET -> 0xFFFF9E72;
            case MONO -> 0xFFE8E8F2;
            default -> 0xFF8FE8FF;
        };
    }

    public int animatedPrimaryColor() {
        if (!rainbow) return primaryColor();
        int rgb = java.awt.Color.HSBtoRGB((System.currentTimeMillis() % 6000L) / 6000.0f, 0.62f, 1.0f);
        return 0xFF000000 | (rgb & 0x00FFFFFF);
    }

    public int accentColor() {
        return switch (palette) {
            case AURORA -> 0xFFB58CFF;
            case SUNSET -> 0xFFFF5E9C;
            case MONO -> 0xFFB0B0C8;
            default -> 0xFF7C8CFF;
        };
    }

    private void clamp() {
        intensity = clamp(intensity, 0.1f, 3.0f);
        particleDensity = clamp(particleDensity, 0.1f, 3.0f);
        animationSpeed = clamp(animationSpeed, 0.1f, 3.0f);
        menuOpacity = clamp(menuOpacity, 0.15f, 1.0f);
        crosshairSize = Math.max(2, Math.min(24, crosshairSize));
        if (palette == null) palette = Palette.CYBER;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}