package com.vismod.gui;

import com.vismod.config.VisualConfig;
import com.vismod.gui.widget.GlassButton;
import com.vismod.render.GlassRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.text.Text;

/** Floating, draggable, responsive glass pause window matching the UI mockup. */
public class CompactPauseScreen extends Screen {
    private int panelWidth = 485;
    private int panelHeight = 465;
    private int panelX;
    private int panelY;
    private boolean positioned;
    private boolean draggingTop;
    private double dragOffsetX;
    private double dragOffsetY;

    public CompactPauseScreen() { super(Text.literal("VisMod Pause")); }

    private void placeDefault() {
        int maxWidth = Math.max(320, width - 24);
        int maxHeight = Math.max(260, height - 24);
        panelWidth = Math.min(panelWidth, maxWidth);
        panelHeight = Math.min(panelHeight, maxHeight);
        if (!positioned) {
            panelX = width / 2 - panelWidth / 2;
            panelY = height / 2 - panelHeight / 2;
            positioned = true;
        }
        panelX = Math.max(12, Math.min(Math.max(12, width - panelWidth - 12), panelX));
        panelY = Math.max(12, Math.min(Math.max(12, height - panelHeight - 12), panelY));
    }

    @Override protected void init() { placeDefault(); rebuildButtons(); }

    private void rebuildButtons() {
        clearChildren();
        int buttonWidth = Math.min(385, panelWidth - 44);
        int left = panelX + (panelWidth - buttonWidth) / 2;
        int top = panelY + Math.min(162, Math.max(78, panelHeight - 285));
        addDrawableChild(GlassButton.of(left, top, buttonWidth, 30, Text.literal("Resume session"), button -> close()));
        int half = (buttonWidth - 8) / 2;
        addDrawableChild(GlassButton.of(left, top + 70, half, 28, Text.literal("Visuals"), button -> client.setScreen(new VisualsConfigScreen(this))));
        addDrawableChild(GlassButton.of(left + half + 8, top + 70, half, 28, Text.literal("Options"), button -> client.setScreen(new OptionsScreen(this, client.options))));
        addDrawableChild(GlassButton.of(left, top + 135, buttonWidth, 28, Text.literal("Leave world / server"), button -> {
            client.disconnect();
            client.setScreen(new CustomTitleScreen());
        }));
    }

    private boolean inTopBar(double mouseX, double mouseY) {
        return mouseX >= panelX && mouseX <= panelX + panelWidth && mouseY >= panelY && mouseY <= panelY + 96;
    }

    @Override public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && inTopBar(mouseX, mouseY)) {
            draggingTop = true; dragOffsetX = mouseX - panelX; dragOffsetY = mouseY - panelY; return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) draggingTop = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingTop && button == 0) {
            panelX = (int) Math.round(mouseX - dragOffsetX);
            panelY = (int) Math.round(mouseY - dragOffsetY);
            placeDefault(); rebuildButtons(); return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (draggingTop && inTopBar(mouseX, mouseY)) {
            int change = (int) Math.round(verticalAmount * 22.0);
            panelWidth = Math.max(340, Math.min(760, panelWidth + change));
            panelHeight = Math.max(280, Math.min(650, panelHeight + change * 2 / 3));
            placeDefault(); rebuildButtons(); return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        placeDefault();
        GlassRenderer.blurBackdrop(context);
        context.fill(0, 0, width, height, 0x14091420);
        GlassRenderer.panel(context, panelX - 6, panelY - 6, panelWidth + 12, panelHeight + 12, 0x182B9EFF, 0x4062C9F2);
        GlassRenderer.panel(context, panelX, panelY, panelWidth, panelHeight, 0x70101E32, 0xB8DDF5FF);
        GlassRenderer.panel(context, panelX + 9, panelY + 9, panelWidth - 18, 66, 0x351D3B5A, 0x4694C4E8);
        context.drawTextWithShadow(textRenderer, "PAUSED", panelX + 35, panelY + 39, VisualConfig.get().primaryColor());
        context.drawTextWithShadow(textRenderer, "drag the top bar  •  scroll while holding to resize", panelX + 35, panelY + 73, 0xB8D9E8F4);
        int noteY = panelY + panelHeight - 58;
        context.drawTextWithShadow(textRenderer, "THE WORLD STAYS VISIBLE AROUND THE GLASS", panelX + 35, noteY, 0xA078A8BC);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override public void close() { if (client != null) client.setScreen(null); }
    @Override public boolean shouldPause() { return true; }
}