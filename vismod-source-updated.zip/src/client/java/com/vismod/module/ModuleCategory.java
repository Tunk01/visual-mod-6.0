package com.vismod.module;

/**
 * Broad grouping used by the "All / Entities / Motion / Starred" filter
 * chips in {@link com.vismod.gui.VisualsConfigScreen}. A module can only
 * belong to one category, but the screen's search box filters across all
 * categories regardless of which chip is selected.
 */
public enum ModuleCategory {
    ENTITIES("Entities"),
    MOTION("Motion"),
    WORLD("World"),
    HUD("HUD"),
    STYLE("Style"),
    MISC("Misc");

    public final String label;

    ModuleCategory(String label) {
        this.label = label;
    }
}
