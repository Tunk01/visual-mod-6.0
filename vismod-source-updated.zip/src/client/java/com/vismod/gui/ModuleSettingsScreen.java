package com.vismod.gui;

import com.vismod.config.ModuleVisualConfig;
import com.vismod.config.VisualConfig;
import com.vismod.gui.widget.GlassButton;
import com.vismod.gui.widget.ModuleSlider;
import com.vismod.module.Module;
import com.vismod.module.ModuleManager;
import com.vismod.render.GlassRenderer;
import com.vismod.render.VisModBackdrop;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Per-module visual controls modeled after the supplied settings reference. */
public class ModuleSettingsScreen extends Screen {
    private final Module module;
    private final Screen parent;
    private final ModuleVisualConfig.Settings settings;

    public ModuleSettingsScreen(Module module, Screen parent) {
        super(Text.literal(module.displayName() + " Settings"));
        this.module = module;
        this.parent = parent;
        this.settings = ModuleVisualConfig.get(module.id());
    }

    @Override
    protected void init() {
        int x = width / 2 - 255;
        int y = height / 2 - 205;
        addDrawableChild(GlassButton.of(x, y, 78, 22, Text.literal("Back"), button -> close()));
        addDrawableChild(GlassButton.of(x + 88, y, 150, 22, Text.literal("Enabled: " + onOff(module.isEnabled())), button -> {
            ModuleManager.setEnabled(module, !module.isEnabled()); clearAndInit();
        }));
        addDrawableChild(GlassButton.of(x + 248, y, 156, 22, Text.literal("Starred: " + onOff(module.isStarred())), button -> {
            ModuleManager.setStarred(module, !module.isStarred()); clearAndInit();
        }));
        addDrawableChild(GlassButton.of(x, y + 62, 198, 24, Text.literal("Choose colour"), button -> {
            settings.primaryColor = nextColor(settings.primaryColor); ModuleVisualConfig.save();
        }));
        addDrawableChild(GlassButton.of(x + 206, y + 62, 198, 24, Text.literal("Highlight colour"), button -> {
            settings.highlightColor = nextColor(settings.highlightColor); ModuleVisualConfig.save();
        }));

        addDrawableChild(new ModuleSlider("Effect count", x, y + 112, 404, 32, 1, 240,
                () -> settings.effectCount, value -> settings.effectCount = (int) Math.round(value)));
        addDrawableChild(new ModuleSlider("Spawn radius", x, y + 154, 404, 32, 2, 48,
                () -> settings.spawnRadius, value -> settings.spawnRadius = (int) Math.round(value)));
        addDrawableChild(new ModuleSlider("Size", x, y + 196, 404, 32, 0.25, 3.0,
                () -> settings.size, value -> settings.size = (float) value));
        addDrawableChild(new ModuleSlider("Animation speed", x, y + 238, 404, 32, 0.10, 3.0,
                () -> settings.animationSpeed, value -> settings.animationSpeed = (float) value));
        addDrawableChild(new ModuleSlider("Opacity", x, y + 280, 404, 32, 0.05, 1.0,
                () -> settings.opacity, value -> settings.opacity = (float) value));
        addDrawableChild(GlassButton.of(x, y + 326, 198, 24, Text.literal("Night only: " + onOff(settings.nightOnly)), button -> {
            settings.nightOnly = !settings.nightOnly; ModuleVisualConfig.save(); clearAndInit();
        }));
        addDrawableChild(GlassButton.of(x + 206, y + 326, 198, 24, Text.literal("Reset"), button -> {
            ModuleVisualConfig.reset(module.id()); close();
        }));
    }

    private int nextColor(int color) {
        int[] colors = {0xFF8FE8FF, 0xFFB58CFF, 0xFFFF9E72, 0xFFFF5E9C, 0xFF65F6C5, 0xFFE8E8F2};
        for (int i = 0; i < colors.length; i++) if (colors[i] == color) return colors[(i + 1) % colors.length];
        return colors[0];
    }
    private String onOff(boolean value) { return value ? "ON" : "OFF"; }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        VisModBackdrop.draw(context, width, height, System.currentTimeMillis());
        int panelWidth = Math.min(900, Math.max(520, width - 32));
        int panelHeight = Math.min(650, Math.max(470, height - 24));
        int x = width / 2 - panelWidth / 2;
        int y = Math.max(12, height / 2 - panelHeight / 2);
        GlassRenderer.panel(context, x, y, panelWidth, panelHeight, 0x8A0E1A2A, 0x78DDF5FF);
        context.drawTextWithShadow(textRenderer, module.displayName(), x + 34, y + 28, VisualConfig.get().primaryColor());
        context.drawTextWithShadow(textRenderer, module.description(), x + 34, y + 54, 0xB5D9E8F4);
        context.drawTextWithShadow(textRenderer, "PER-MODULE COSMETIC SETTINGS", x + 34, y + panelHeight - 28, 0x909FB7C8);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override public void close() { if (client != null) client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}